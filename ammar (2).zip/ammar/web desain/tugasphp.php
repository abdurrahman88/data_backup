<!DOCTYPE html>
<html>
<body>

<?php
echo "www.xxx.com";
?>

</body>
</html>